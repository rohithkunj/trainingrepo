package com.ingrain.spring.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ingrain.spring.entities.LeaveBalanceEntity;
import com.ingrain.spring.entities.LeaveEntity;
import com.ingrain.spring.services.EmployeeLeaveService;

@RestController
@RequestMapping("EMS")
public class LeaveRest {

	LeaveEntity leave;
	@Autowired
	private EmployeeLeaveService employeeLeaveService;

	@RequestMapping(value = "/applyLeave", method = RequestMethod.POST)
	public boolean applyForLeave(@RequestBody LeaveEntity leave) {
		return employeeLeaveService.applyLeave(leave);
	}

	@RequestMapping(value = "/cancelLeave", method = RequestMethod.PUT)
	public boolean cancelLeaveRequest(@RequestBody LeaveEntity leave) {
		return employeeLeaveService.cancelLeave(leave);
	}

	@RequestMapping(value = "/rejectLeave", method = RequestMethod.PUT)
	public boolean rejectLeaveRequest(@RequestBody LeaveEntity leave) {
		return employeeLeaveService.rejectLeave(leave);
	}

	@RequestMapping(value = "/acceptLeave", method = RequestMethod.PUT)
	public boolean acceptLeaveRequest(@RequestBody LeaveEntity leave) {
		return employeeLeaveService.acceptLeaveRequest(leave);
	}

	@RequestMapping(value = "/leaveRequests/{employee_id}", method = RequestMethod.GET)
	public List<LeaveEntity> viewLeaveRequest(@PathVariable String employee_id) {
		return employeeLeaveService.getLeaveRequests(employee_id);
	}

	@RequestMapping(value = "/leaves/{employee_id}", method = RequestMethod.GET)
	public List<LeaveEntity> viewLeavesOfEmployee(@PathVariable String employee_id) {
		return employeeLeaveService.getLeavesOfEmployee(employee_id);
	}

	@RequestMapping(value = "/appliedLeaves/{employee_id}", method = RequestMethod.GET)
	public List<LeaveEntity> viewAppliedLeavesOfEmployee(@PathVariable String employee_id) {
		return employeeLeaveService.getAppliedLeavesOfEmployee(employee_id);
	}

	@RequestMapping(value = "/leaveBalance/{employee_id}", method = RequestMethod.GET)
	public LeaveBalanceEntity viewLeaveBalance(@PathVariable String employee_id) {
		return employeeLeaveService.getLeaveBalance(employee_id);
	}

}
