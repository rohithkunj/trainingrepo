package com.ingrain.spring.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ingrain.spring.entities.EmployeeEntity;
import com.ingrain.spring.entities.LoginEntity;

@Repository
public interface LoginRepository extends JpaRepository<LoginEntity,String >{
	@Query("select e from EmployeeEntity e where e.login.username =:username")
	public EmployeeEntity getEmployee(@Param("username") String username);
		
}
