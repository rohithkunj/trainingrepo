package com.ingrain.spring.constants;

public class Constant {
	public static String url;
}
